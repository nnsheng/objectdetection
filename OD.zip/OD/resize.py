import cv2
import os

# NOTE:
# 1 first resize then label data or will cause label mismatch
# 2
dir = os.listdir("images/")
for i in dir:
    print(i)

pic = cv2.imread('images/videoplayback2560.jpg')

cv2.imshow('', pic)
cv2.waitKey(0)
cv2.destroyAllWindows()

pic = cv2.resize(pic, (400, 400), interpolation=cv2.INTER_CUBIC)
cv2.imshow('', pic)
cv2.waitKey(0)
cv2.destroyAllWindows()

cv2.imwrite("images_new/videoplayback2560.jpg", pic)